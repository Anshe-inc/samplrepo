#include "main.h"


//this is for simple testings
void testing();
void test_load(const char* filename);