# HOW TO RUN
    For `Linux` systems only
Just run _`run.sh`_
